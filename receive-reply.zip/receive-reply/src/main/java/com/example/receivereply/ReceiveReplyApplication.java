package com.example.receivereply;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReceiveReplyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReceiveReplyApplication.class, args);
	}

}
